﻿namespace RentalSystem {
    
    
    public partial class HomeAppliance {
        partial class rentAppliancesViewDataTable
        {
        }
    
        partial class rentAppliancesDetailViewDataTable
        {
        }
    
        partial class adminDataTable
        {
        }
    }
}

namespace RentalSystem.HomeApplianceTableAdapters {
    partial class rentAppliancesTableAdapter
    {
    }
    
    
    public partial class adminTableAdapter {
    }
}
