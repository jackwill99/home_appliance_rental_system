﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;


namespace RentalSystem
{
    public class RentServiceControl
    {
        public double totalPrice = 0;

        // rent service user, it may be customer or admin
        public string userName;
        public string userId;

        

    }
}
